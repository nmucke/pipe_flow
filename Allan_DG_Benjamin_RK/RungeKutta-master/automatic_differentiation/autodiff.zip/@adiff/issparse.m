function b = issparse(a)
b = issparse(a.dx);