function c = isreal(a)
% ISREAL for adiff objects
c = isreal(a.x);